
class WebSocketDefine:
    # Uri = "wss://dstream.binance.com/ws"
    # testnet
    Uri = "wss://dstream.binancefuture.com/ws"
    # testnet new spec
    # Uri = "wss://sdstream.binancefuture.com/ws"

class RestApiDefine:
    # Url = "https://dapi.binance.com"
    # testnet
    Url = "https://testnet.binancefuture.com"




