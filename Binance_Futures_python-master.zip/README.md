# Notice of Change
This repository is no longer recommended for use in production. Instead, please use this one: https://github.com/binance/binance-futures-connector-python. This code will be removed in the future. <br/><br/>
This repository will be set to offline on 2023-06-08.
